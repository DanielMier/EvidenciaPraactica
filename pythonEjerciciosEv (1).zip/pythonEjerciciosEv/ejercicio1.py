print('Introduce una ciudad y con 0 sales del programa')
print('-----------------------------------------------')

#nos pide el nombre de una ciudad
ciudad=input('Introduce una ciudad: ')
#Si pulsas 0 sale de la aplicacion si no puedes escrtibir la ciudad
if ciudad == '0':
    print('has salido')
else:
    #Mientras que no sea sevilla, madrid o valencia, va a pedir otra ciudad, si no preguta cuantas noches de hotel
    while ciudad.lower() != 'sevilla' and ciudad.lower() != 'madrid' and ciudad.lower() != 'valencia':
        ciudad = input('Escribe otra ciudad: ')
    hotel = int(input('Cuantas noches de hotel: '))
    print(f'Vas a pasar {hotel} noches en {ciudad.lower()}')