#creacion clase rectangulo
class Rectangulo():
    def __init__(self, nombre, base, altura, nlados):
        self.nombre=nombre
        self.base=base
        self.altura=altura
        self.nlados=nlados

    # esta funcion te hace el area
    def area(self):
        area=(self.base * self.altura)
        print('El nombre es: ', self.nombre)
        print('El area es: ', area)
#creacion clase pentagono
class Pentagono():
    def __init__(self, nombre, nlados, apotema, base):
        self.nombre=nombre
        self.nlados=nlados
        self.apotema=apotema
        self.base=base

    # esta funcion te hace el area
    def area(self):
        area = ((self.base * self.nlados) * self.apotema) / 2
        print('El nombre es: ', self.nombre)
        print('El area es: ', area)
#creacion clase cuadrado
class Cuadrado():
    def __init__(self, nombre, nlados):
        self.nombre=nombre
        self.nlados=nlados
    #esta funcion te hace el area
    def area(self):
        area = self.nlados * self.nlados
        print('El nombre es: ', self.nombre)
        print('El area es: ', area)


elegir=input('Que quieres hacer:\n1. Cuadrado\n2. Pentagono\n3. Rectangulo\n')

#diseña por consola una aplicacion que pida el nombre y la longitud.
#ademas mostrara el nombre y el area
match elegir:
    case '1':
        cuadrado1=Cuadrado(input('Nombre: '),int(input('Lado: ')))
        cuadrado1.area()
    case '2':
        pentagono1=Pentagono(input('Nombre: '),5,int(input('Apotema: ')),int(input('Base: ')))
        pentagono1.area()
    case '3':
        rectangulo1 = Rectangulo(input('Nombre: '), int(input('Base: ')), int(input('Altura: ')), 4)
        rectangulo1.area()
    case _:
        print('Elige una opcion valida')

