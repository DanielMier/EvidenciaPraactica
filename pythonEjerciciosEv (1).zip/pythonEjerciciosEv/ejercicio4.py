import random
from datetime import datetime
numero = random.randint(1, 9)
try:
    # hora inicio aplicacion
    print('Comienza el test')
    fecha_inicio = datetime.now()
    fecha_inicio_format = fecha_inicio.strftime("%H:%M:%S")
    print(f'Fecha inicio de test {fecha_inicio_format}')

    # almacena la respuesta
    respuesta = int(input('Acierta el Número: '))
    intento = 1  # nº intentos
    while respuesta != numero:
        print('has fallado. Vuelve a intentarlo')
        intento = intento + 1 #suma 1 por cada intento
        respuesta = int(input('Acierta el Número: '))
    print('respuesta correcta')
    # si utiliza mas de 4 intetnos no has pasado la prueba
    if intento < 4:
        print('Has pasado la prueba')
    else:
        print(f'No has pasado la prueba, has necesitado {intento} intentos')


except:
    print('algo va mal')
finally:
    # muestra la fecha de finalizacion del test, se haya acertado o no
    fecha_fin = datetime.now()
    fecha_fin_format = fecha_fin.strftime("%H:%M:%S")
    print(f'Fecha fin de test {fecha_fin_format}')