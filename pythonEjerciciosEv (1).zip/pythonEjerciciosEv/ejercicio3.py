#coleccion donde introduces 4 ciudades y madrid
#las ciudades se muestran alfabeticamente

ciudades=['madrid',input('Introduce nombre ciudad: '),input('Introduce nombre ciudad: '),input('Introduce nombre ciudad: '),input('Introduce nombre ciudad: ')]

ciudades.sort()
for ciudad in ciudades:
    print(ciudad.lower())

#Añade una ciudad al final del listado de ciudades anterior. Y elimina madrid
print('\nAñade una ciudad al final del listado de ciudades anterior. Y elimina madrid')
print('----------------------------------------------------------------------------')
ciudades.append('malaga')
ciudades.remove('madrid')
ciudades.sort()
for ciudad in ciudades:
    print(ciudad)

#Muestra las ciudades en mayúsculas y el número de letras que la forman
print('\nMuestra las ciudades en mayúsculas y el número de letras que la forman')
print('----------------------------------------------------------------------------')
ciudades.sort()
for ciudad in ciudades:
    print(ciudad.upper())
    print('Contiene',len(ciudad),'letras')

#Para todas las ciudades reemplaza las a por la e
print('\nPara todas las ciudades reemplaza las a por la e')
print('----------------------------------------------------------------------------')
ciudades.sort()
for ciudad in ciudades:
    print(ciudad.replace('a','e'))